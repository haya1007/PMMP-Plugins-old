<?php

namespace Warning;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\player\PlayerCommandPreprocessEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\network\mcpe\protocol\AddPlayerPacket;
use pocketmine\network\mcpe\protocol\RemoveEntityPacket;
use pocketmine\scheduler\Task;
use pocketmine\utils\Config;

use Warning\task\ChangeNameTag;
class Main extends PluginBase implements Listener {

	public function onEnable() {
		$this->getServer()->getPluginManager()->registerEvents($this, $this);
		$this->getLogger()->info("§a[起動] §bWarning §aを起動しました。");
		if (!file_exists($this->getDataFolder())) {mkdir($this->getDataFolder());}
	}

	public function onDisable() {
		$this->getLogger()->info("§c[終了] §bWarning §aを終了しています...");
	}

	public function Join(PlayerJoinEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$folder = $this->getFolder($name);
		$this->config[$name] = new Config($folder, Config::JSON, [
			'warn'     => 0
		]);
		$this->config[$name]->save();
		$this->getScheduler()->scheduleDelayedTask(new ChangeNameTag($this, $player), 30);
	}

	public function onBreak(BlockBreakEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$warn = $this->getWarn($name);
		if($warn >= 2){
			$event->setCancelled();
			$player->sendMessage("どんまあああああああいいいいいい！！！！");
		}
	}

	public function onPlace(BlockPlaceEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$warn = $this->getWarn($name);
		if($warn >= 2){
			$event->setCancelled();
			$player->sendMessage("どんまあああああああいいいいいい！！！！");
		}
	}

	public function onChat(PlayerCommandPreprocessEvent $event){
		$player = $event->getPlayer();
		$name = $player->getName();
		$message = $event->getMessage();
		$warn = $this->getWarn($name);
		if(substr($message, 0, 1) === "/"){
			if($warn === 3){
				$event->setCancelled();
				$player->sendMessage("どんまあああああああいいいいいい！！！！");
			}
		}
	}

	public function onCChat(PlayerChatEvent $e){
		$p = $e->getPlayer();
		$name = $p->getName();
		$warn = $this->getWarn($name);
		if($warn === 4){
			$event->setCancelled();
			$p->sendMessage("しね");
		}
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
		 
		if($label === "/warn"){
			if(isset($args[0]) && isset($args[1])){
				$player = $this->getServer()->getPlayer($args[0]);
				if(isset($player)){
					if(is_numeric($args[1])){
						$player_name = $player->getName();
						if($args[1] == 0){
							$this->setWarn($player_name, 0);
							$sender->sendMessage("§l§a".$player_name."の警告を消しました");
						}elseif($args[1] == 1){
							$this->setWarn($player_name, 1);	
							$sender->sendMessage("§l§a".$player_name."に警告1を付与しました");					
						}elseif($args[1] == 2){
							$this->setWarn($player_name, 2);	
							$sender->sendMessage("§l§a".$player_name."に警告2を付与しました");							
						}elseif($args[1] == 3){
							$this->setWarn($player_name, 3);	
							$sender->sendMessage("§l§a".$player_name."に警告3を付与しました");						
						}elseif($args[1] == 4){
							$this->setWarn($player_name, 4);	
							$sender->sendMessage("§l§a".$player_name."に警告4を付与しました");							
						}else{
							$sender->sendMessage("§l§c//warn [PlayerName] [Number 0~4]");
							return true;
						}
						$player->sendMessage("§l§a警告が付与されました");
						$this->broadcastMessage("§l§c[Warning] §6".$player_name."に警告が付与されました");
						$this->setNameTag($player);
						return true;
					}else{
						$sender->sendMessage("§l§c数字で入力してください");
					}
				}else{
					$sender->sendMessage("§l§cそのプレイヤーは存在しません");
				}
			}else{
				$sender->sendMessage("§l§c//warn [PlayerName] [Number 0~4]");
			}
			return true;
		}
	}

	public function setNameTag($player){
		$name = $player->getName();
		$mark = $this->getWarnMark($name);
		if(!is_null($mark)){
			$tag = $player->getNameTag();
			$display_name = $player->getDisplayName();
			$player->setNameTag($mark." ".$tag);
			$player->setDisplayName($mark." ".$display_name);
		}
	}

	public function setDisplay(Player $player, string $tag){
		$remove = new RemoveEntityPacket();
		$remove->entityUniqueId = $player->getId();
		$pk = new AddPlayerPacket();
		$pk->uuid = $player->getUniqueId();
		$pk->username = $tag;
		$pk->entityRuntimeId = $player->getId();
		$pk->position = $player->asVector3();
		$pk->motion = $player->getMotion();
		$pk->yaw = $player->yaw;
		$pk->pitch = $player->pitch;
		$pk->item = $player->getInventory()->getItemInHand();
		$pk->metadata = $player->getDataPropertyManager()->getAll();
		foreach($this->getServer()->getOnlinePlayers() as $players){
			if($players->getId() !== $player->getId()){
				$players->dataPacket($remove);
				$players->dataPacket($pk);
			}
		}
	}


	public function getWarnMark($name){
		$warn = $this->getWarn($name);
		if($warn === 1){
			$color = "§l§e";
		}elseif($warn === 2){
			$color = "§l§6";
		}elseif($warn === 3){
			$color = "§l§d";
		}elseif($warn === 4){
			$color = "§l§c";
		}else{
			return null;
		}
		$mark = $color."⚠§r";
		return $mark;
	}

	public function getFolder($name){
		$sub = substr($name, 0, 1);
		$upper = strtoupper($sub);
		$folder = $this->getDataFolder().$upper.'/';
		if(!file_exists($folder)) mkdir($folder);
		$lower = strtolower($name);
		return $folder .= $lower.'.json';
	}

	public function getWarn($name){
		return $this->config[$name]->get("warn");
	}

	public function setWarn($name, $warn){
		$this->config[$name]->set("warn", $warn);
		$this->config[$name]->save();
	}

	public function broadcastMessage($message){
		foreach($this->getServer()->getOnlinePlayers() as $players){
			$players->sendMessage($message);
		}
	}
}
