<?php

namespace Warning\task;

use pocketmine\Player;
use pocketmine\Server;
use pocketmine\scheduler\Task;

use Warning\main;

class ChangeNameTag extends Task{
	function __construct(main $owner, Player $player){
		$this->owner = $owner;
		$this->player = $player;
	}

	function onRun(int $currentTick){
		$this->owner->setNameTag($this->player);
	}
}